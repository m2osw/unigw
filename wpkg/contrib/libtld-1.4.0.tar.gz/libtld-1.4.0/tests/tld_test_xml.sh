#!/bin/sh
xmllint ../src/tld_data.xml >/dev/null
